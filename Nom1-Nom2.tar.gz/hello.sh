#!/bin/bash
echo "Exécution du programme HelloWorld..."
java -cp bin HelloWorld
echo "Exécution terminée."
