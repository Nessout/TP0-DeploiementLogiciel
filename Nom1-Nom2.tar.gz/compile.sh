#!/bin/bash
echo "Compilation du code Java..."
javac -d bin src/*.java
echo "Compilation terminée, les fichiers .class sont dans le répertoire bin."
